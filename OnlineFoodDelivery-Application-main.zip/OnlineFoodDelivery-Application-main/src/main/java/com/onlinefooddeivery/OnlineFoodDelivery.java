package com.onlinefooddeivery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication
public class OnlineFoodDelivery{

	public static void main(String[] args) {
		SpringApplication.run(OnlineFoodDelivery.class, args);

	}

}
